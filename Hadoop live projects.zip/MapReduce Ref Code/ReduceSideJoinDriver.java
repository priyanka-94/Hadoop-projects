import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class ReduceSideJoinDriver  {

	public static void main(String[] args) throws Exception {
		
		Configuration config = new Configuration();
		Job job = new Job(config, "Reducer Side Join Example");
		job.setJarByClass(ReduceSideJoinDriver.class);
		job.setNumReduceTasks(1);
		
		MultipleInputs.addInputPath(job, new Path(args[0]),TextInputFormat.class, 
				CustomerMap.class);
		MultipleInputs.addInputPath(job, new Path(args[1]),TextInputFormat.class, 
				CustomerTransMap.class);
		job.setReducerClass(JoinExampleReduce.class);
	
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		FileOutputFormat.setOutputPath(job, new Path(args[2]));
		
		FileSystem.get(config).delete(new Path(args[2]), true);
		job.waitForCompletion(true);
	}

}