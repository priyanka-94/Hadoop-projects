import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class MyPartitioner extends Partitioner<Text, IntWritable>
	{
		public int getPartition(Text key, IntWritable value, int parttionnumber) {
			
			String myKey = key.toString().toLowerCase();
		
			if(myKey.compareTo("h") < 0 )
			{
				return 0;
			}
			else if(myKey.compareTo("m") < 0)
			{
				return 1;
			}
			else 
			{
				return 2;
			}
		}
	}
