
public enum LineCounter {
	Lines

}
