import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class StatePopulationDriver  {

	public static void main(String[] args) throws Exception{
		Configuration config = new Configuration();
		
		DistributedCache.addCacheFile(new URI("/user/ksureka/mapreduce/state.txt"), config);
		Job job = new Job(config, "MAP Side Join Example");			
		job.setJarByClass(StatePopulationDriver.class);
		
		//Don't need a reducer in this program as Mapper output is going to be job output
		job.setNumReduceTasks(0);	
		job.setMapperClass(StatePopulationMap.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);			
		Path inputPath = new Path(args[0]);
		Path outputPath = new Path(args[1]);
		
		FileInputFormat.addInputPath(job, inputPath);
		FileOutputFormat.setOutputPath(job, outputPath);
		
		FileSystem.get(config).delete(new Path(args[1]), true);
		job.waitForCompletion(true);		

	}

}